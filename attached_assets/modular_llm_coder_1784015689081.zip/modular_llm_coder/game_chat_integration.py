from __future__ import annotations

from dataclasses import dataclass

from llm_coder import CodingAgent


@dataclass
class GameChatController:
    coding_agent: CodingAgent

    def handle_chat_message(self, text: str) -> str:
        """
        Route explicit development commands to the coding agent.

        Keep normal game chat separate from code-editing mode.
        """
        prefix = "/dev "
        if not text.startswith(prefix):
            return "Normal game-chat message received."

        request = text[len(prefix):].strip()
        if not request:
            return "Usage: /dev <development task>"

        return self.coding_agent.run(request)
