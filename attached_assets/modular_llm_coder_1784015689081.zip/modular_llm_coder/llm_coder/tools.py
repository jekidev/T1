from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from typing import Any, Callable

from .workspace import Workspace, WorkspaceError


ToolHandler = Callable[[dict[str, Any]], Any]


@dataclass(slots=True)
class RegisteredTool:
    name: str
    description: str
    parameters: dict[str, Any]
    handler: ToolHandler
    requires_approval: bool = False

    def schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, RegisteredTool] = {}

    def register(self, tool: RegisteredTool) -> None:
        if tool.name in self._tools:
            raise ValueError(f"Duplicate tool: {tool.name}")
        self._tools[tool.name] = tool

    def schemas(self) -> list[dict[str, Any]]:
        return [tool.schema() for tool in self._tools.values()]

    def execute(
        self,
        name: str,
        arguments: dict[str, Any],
        approve: Callable[[str, dict[str, Any]], bool],
    ) -> Any:
        tool = self._tools.get(name)
        if tool is None:
            raise KeyError(f"Unknown tool: {name}")

        if tool.requires_approval and not approve(name, arguments):
            return {"ok": False, "error": "User rejected tool execution"}

        return tool.handler(arguments)


def _object_schema(properties: dict[str, Any], required: list[str] | None = None) -> dict:
    return {
        "type": "object",
        "properties": properties,
        "required": required or [],
        "additionalProperties": False,
    }


def build_default_tools(
    workspace: Workspace,
    allowed_commands: set[str] | None = None,
) -> ToolRegistry:
    allowed_commands = allowed_commands or {
        "python",
        "python3",
        "pytest",
        "ruff",
        "mypy",
        "npm",
        "pnpm",
        "node",
        "git",
    }

    registry = ToolRegistry()

    registry.register(RegisteredTool(
        name="list_files",
        description="List files inside the sandboxed project workspace.",
        parameters=_object_schema({
            "pattern": {"type": "string", "default": "**/*"},
            "limit": {"type": "integer", "minimum": 1, "maximum": 2000, "default": 500},
        }),
        handler=lambda a: {
            "files": workspace.list_files(a.get("pattern", "**/*"), a.get("limit", 500))
        },
    ))

    registry.register(RegisteredTool(
        name="read_file",
        description="Read a UTF-8 text file inside the project workspace.",
        parameters=_object_schema({
            "path": {"type": "string"},
        }, ["path"]),
        handler=lambda a: {
            "path": a["path"],
            "content": workspace.read_text(a["path"]),
        },
    ))

    registry.register(RegisteredTool(
        name="search_code",
        description="Search text across project files.",
        parameters=_object_schema({
            "query": {"type": "string"},
            "pattern": {"type": "string", "default": "**/*"},
            "limit": {"type": "integer", "minimum": 1, "maximum": 500, "default": 100},
        }, ["query"]),
        handler=lambda a: {
            "matches": workspace.search_text(
                a["query"],
                a.get("pattern", "**/*"),
                a.get("limit", 100),
            )
        },
    ))

    def write_file(arguments: dict[str, Any]) -> dict:
        workspace.write_text(arguments["path"], arguments["content"])
        return {"ok": True, "path": arguments["path"]}

    registry.register(RegisteredTool(
        name="write_file",
        description="Create or fully replace a text file. Requires approval.",
        parameters=_object_schema({
            "path": {"type": "string"},
            "content": {"type": "string"},
        }, ["path", "content"]),
        handler=write_file,
        requires_approval=True,
    ))

    def replace_text(arguments: dict[str, Any]) -> dict:
        path = arguments["path"]
        old = arguments["old"]
        new = arguments["new"]
        expected = arguments.get("expected_replacements", 1)

        content = workspace.read_text(path)
        count = content.count(old)
        if count != expected:
            raise WorkspaceError(
                f"Expected {expected} occurrence(s), found {count}; refusing ambiguous edit"
            )

        workspace.write_text(path, content.replace(old, new))
        return {"ok": True, "path": path, "replacements": count}

    registry.register(RegisteredTool(
        name="replace_text",
        description="Perform an exact, bounded text replacement in one file. Requires approval.",
        parameters=_object_schema({
            "path": {"type": "string"},
            "old": {"type": "string"},
            "new": {"type": "string"},
            "expected_replacements": {"type": "integer", "minimum": 1, "default": 1},
        }, ["path", "old", "new"]),
        handler=replace_text,
        requires_approval=True,
    ))

    registry.register(RegisteredTool(
        name="run_command",
        description="Run an allowlisted command in the workspace without a shell.",
        parameters=_object_schema({
            "argv": {
                "type": "array",
                "items": {"type": "string"},
                "minItems": 1,
            },
            "timeout_seconds": {
                "type": "integer",
                "minimum": 1,
                "maximum": 300,
                "default": 60,
            },
        }, ["argv"]),
        handler=lambda a: workspace.run_command(
            a["argv"],
            allowed_commands,
            a.get("timeout_seconds", 60),
        ),
        requires_approval=True,
    ))

    registry.register(RegisteredTool(
        name="git_diff",
        description="Show the current git diff.",
        parameters=_object_schema({}),
        handler=lambda a: workspace.run_command(
            ["git", "diff", "--", "."], allowed_commands, 30
        ),
    ))

    registry.register(RegisteredTool(
        name="git_status",
        description="Show concise git status.",
        parameters=_object_schema({}),
        handler=lambda a: workspace.run_command(
            ["git", "status", "--short"], allowed_commands, 30
        ),
    ))

    registry.register(RegisteredTool(
        name="git_commit",
        description="Commit approved changes to git. Requires approval.",
        parameters=_object_schema({
            "message": {"type": "string", "minLength": 1, "maxLength": 200},
        }, ["message"]),
        handler=lambda a: _git_commit(workspace, allowed_commands, a["message"]),
        requires_approval=True,
    ))

    return registry


def _git_commit(workspace: Workspace, allowed_commands: set[str], message: str) -> dict:
    add_result = workspace.run_command(["git", "add", "--all"], allowed_commands, 30)
    if add_result["exit_code"] != 0:
        return add_result
    return workspace.run_command(
        ["git", "commit", "-m", message],
        allowed_commands,
        60,
    )
