from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

from .models import LLMAdapter
from .tools import ToolRegistry


DEFAULT_SYSTEM_PROMPT = """
You are an embedded software-engineering agent working on the same application
that hosts this chat.

Rules:
1. Inspect relevant files before editing.
2. Make small, targeted changes.
3. Never access files outside the workspace.
4. Never request secrets or expose environment variables.
5. Prefer exact replacements over full-file rewrites.
6. Run relevant tests after edits.
7. Review git diff before finishing.
8. Do not claim success unless tests or direct inspection support it.
9. Ask for approval through the tool layer when a persistent change is required.
10. Stop when the requested task is complete.
""".strip()


class CodingAgent:
    def __init__(
        self,
        adapter: LLMAdapter,
        tools: ToolRegistry,
        *,
        approve: Callable[[str, dict[str, Any]], bool] | None = None,
        system_prompt: str = DEFAULT_SYSTEM_PROMPT,
        max_steps: int = 20,
    ) -> None:
        self.adapter = adapter
        self.tools = tools
        self.approve = approve or (lambda _name, _args: False)
        self.system_prompt = system_prompt
        self.max_steps = max_steps

    def run(self, user_request: str) -> str:
        messages: list[dict[str, Any]] = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": user_request},
        ]

        for _ in range(self.max_steps):
            turn = self.adapter.complete(messages, self.tools.schemas())

            assistant_message: dict[str, Any] = {
                "role": "assistant",
                "content": turn.content,
            }

            if turn.tool_calls:
                assistant_message["tool_calls"] = [
                    {
                        "id": call.id,
                        "type": "function",
                        "function": {
                            "name": call.name,
                            "arguments": json.dumps(call.arguments),
                        },
                    }
                    for call in turn.tool_calls
                ]

            messages.append(assistant_message)

            if not turn.tool_calls:
                return turn.content

            for call in turn.tool_calls:
                try:
                    result = self.tools.execute(
                        call.name,
                        call.arguments,
                        self.approve,
                    )
                    payload = {"ok": True, "result": result}
                except Exception as exc:
                    payload = {
                        "ok": False,
                        "error": f"{type(exc).__name__}: {exc}",
                    }

                messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "name": call.name,
                    "content": json.dumps(payload, ensure_ascii=False),
                })

        return "Stopped because the maximum number of agent steps was reached."
