from __future__ import annotations

import json
from typing import Any

from .models import AssistantTurn, ToolCall


class OpenAICompatibleAdapter:
    """
    Minimal adapter for OpenAI-compatible chat-completions endpoints.

    The injected `client` must expose:
        client.chat.completions.create(...)
    """

    def __init__(self, client: Any, model: str) -> None:
        self.client = client
        self.model = model

    def complete(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]],
    ) -> AssistantTurn:
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            tools=tools,
            tool_choice="auto",
            temperature=0.1,
        )

        message = response.choices[0].message
        calls: list[ToolCall] = []

        for raw_call in message.tool_calls or []:
            calls.append(ToolCall(
                id=raw_call.id,
                name=raw_call.function.name,
                arguments=json.loads(raw_call.function.arguments or "{}"),
            ))

        return AssistantTurn(
            content=message.content or "",
            tool_calls=calls,
        )
