from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass
from pathlib import Path


class WorkspaceError(RuntimeError):
    pass


@dataclass(slots=True)
class Workspace:
    root: Path
    max_file_bytes: int = 1_000_000

    def __post_init__(self) -> None:
        self.root = self.root.resolve()
        if not self.root.exists() or not self.root.is_dir():
            raise WorkspaceError(f"Invalid workspace: {self.root}")

    def resolve(self, relative_path: str) -> Path:
        if not relative_path or "\x00" in relative_path:
            raise WorkspaceError("Invalid path")

        candidate = (self.root / relative_path).resolve()
        try:
            candidate.relative_to(self.root)
        except ValueError as exc:
            raise WorkspaceError("Path escapes workspace") from exc

        return candidate

    def read_text(self, relative_path: str) -> str:
        path = self.resolve(relative_path)
        if not path.is_file():
            raise WorkspaceError(f"File not found: {relative_path}")
        if path.stat().st_size > self.max_file_bytes:
            raise WorkspaceError("File exceeds size limit")
        return path.read_text(encoding="utf-8")

    def write_text(self, relative_path: str, content: str) -> None:
        path = self.resolve(relative_path)
        encoded = content.encode("utf-8")
        if len(encoded) > self.max_file_bytes:
            raise WorkspaceError("Content exceeds size limit")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def list_files(self, pattern: str = "**/*", limit: int = 500) -> list[str]:
        output: list[str] = []
        for path in self.root.glob(pattern):
            if path.is_file():
                output.append(path.relative_to(self.root).as_posix())
                if len(output) >= limit:
                    break
        return sorted(output)

    def search_text(self, query: str, pattern: str = "**/*", limit: int = 100) -> list[dict]:
        matches: list[dict] = []
        for rel in self.list_files(pattern=pattern, limit=5000):
            try:
                text = self.read_text(rel)
            except (UnicodeDecodeError, WorkspaceError):
                continue
            for line_no, line in enumerate(text.splitlines(), 1):
                if query.lower() in line.lower():
                    matches.append({"file": rel, "line": line_no, "text": line[:500]})
                    if len(matches) >= limit:
                        return matches
        return matches

    def run_command(
        self,
        argv: list[str],
        allowed_commands: set[str],
        timeout_seconds: int = 60,
    ) -> dict:
        if not argv:
            raise WorkspaceError("Command is empty")

        executable = Path(argv[0]).name.lower()
        if executable not in allowed_commands:
            raise WorkspaceError(f"Command not allowed: {executable}")

        env = {
            "PATH": os.environ.get("PATH", ""),
            "PYTHONPATH": str(self.root),
            "NO_COLOR": "1",
        }

        completed = subprocess.run(
            argv,
            cwd=self.root,
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            shell=False,
        )

        return {
            "exit_code": completed.returncode,
            "stdout": completed.stdout[-20_000:],
            "stderr": completed.stderr[-20_000:],
        }
