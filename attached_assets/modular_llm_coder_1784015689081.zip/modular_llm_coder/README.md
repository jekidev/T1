# Modular LLM Coder

Provider-agnostic coding-agent kernel for embedding inside a game/chat application.

## Features

- Sandboxed workspace access
- Read/list/search/write/replace tools
- Command allowlist
- Test execution
- Git diff/status/commit support
- Approval gate for destructive or persistent changes
- Adapter interface for any LLM provider
- Agent loop with tool calls and bounded iterations

## Install

```bash
pip install -e .
```

Optional:

```bash
pip install httpx
```

## Run

```bash
python example.py
```

Set your project path and connect an LLM adapter by implementing:

```python
class MyAdapter:
    def complete(self, messages, tools):
        ...
```

The adapter must return an `AssistantTurn`.

## Recommended operating model

1. LLM reads code.
2. LLM proposes targeted edits.
3. Agent applies edits in the sandbox.
4. Tests run.
5. User approves.
6. Git commit is created.

Never expose unrestricted shell, filesystem roots, secrets, production credentials, or deployment tokens.
