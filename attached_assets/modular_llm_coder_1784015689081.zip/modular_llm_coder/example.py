from pathlib import Path

from llm_coder import CodingAgent, Workspace, build_default_tools
from llm_coder.openai_compatible import OpenAICompatibleAdapter


def approval_dialog(tool_name: str, arguments: dict) -> bool:
    print(f"\nApproval required: {tool_name}")
    print(arguments)
    return input("Approve? [y/N]: ").strip().lower() == "y"


def main() -> None:
    # Example using an OpenAI-compatible SDK/client.
    # from openai import OpenAI
    # client = OpenAI(
    #     base_url="https://openrouter.ai/api/v1",
    #     api_key="YOUR_KEY_FROM_A_SECRET_STORE",
    # )
    # adapter = OpenAICompatibleAdapter(client, "your-model")

    raise SystemExit(
        "Connect your LLM client in example.py, then instantiate CodingAgent."
    )

    # workspace = Workspace(Path("./your_game_project"))
    # tools = build_default_tools(workspace)
    # agent = CodingAgent(
    #     adapter=adapter,
    #     tools=tools,
    #     approve=approval_dialog,
    # )
    # result = agent.run(
    #     "Add a pause menu to the game. Inspect the architecture first, "
    #     "implement the smallest coherent change, run tests, and review the diff."
    # )
    # print(result)


if __name__ == "__main__":
    main()
